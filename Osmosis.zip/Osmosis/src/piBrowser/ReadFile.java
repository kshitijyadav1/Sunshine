
package piBrowser;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
public class ReadFile extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField addressBar;
	private JEditorPane display;
	
	//constructor
	public ReadFile() {
		super("PiBrowser");
		addressBar = new JTextField("https://www.google.com");
		addressBar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				loadCrap(event.getActionCommand());
			}
		});
		add(addressBar, BorderLayout.NORTH);
		
		display = new JEditorPane();
		display.setEditable(false);
		display.addHyperlinkListener(new HyperlinkListener() {

			@Override
			public void hyperlinkUpdate(HyperlinkEvent event) {
				if(event.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
					loadCrap(event.getURL().toString());
				}
			}
			
		});
		add(new JScrollPane(display), BorderLayout.CENTER);
		setSize(500,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	  
	
	private void loadCrap(String userText) {
		//this method is used for display the data on the screen.
		try {
			display.setPage(userText);
			addressBar.setText(userText);
		} catch(Exception ex) {
			System.out.print("Something went wrong.");
		}
 		
	}
	public static void main(String[] args) {
		new ReadFile();
	}
	
}
