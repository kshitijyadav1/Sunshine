package ganit;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.application.*;
import javafx.event.*;
import javafx.geometry.*;
public class TemperatureValueConversion extends Application {
	private TextField textField = new TextField();
	private RadioButton fahrenheit = new RadioButton("Fahrenheit");
	private RadioButton celsius = new RadioButton("Celsius");
	private Label queryTemp = new Label();
	private Label result = new Label();
	private Label input = new Label();
	private Button cal = new Button("Calculate");
	
	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(10,10,10,10));
		String text = "Here you can convert the temperature between celsius and fahrenheit by inputing degree in the textfield box.";
		Label label = new Label(text);
		label.setWrapText(true);
		
		pane.setTop(label);
		ToggleGroup group = new ToggleGroup();
		fahrenheit.setToggleGroup(group);
		celsius.setToggleGroup(group);
		celsius.setSelected(true);
		input.setText("Input celsius degree : ");
		pane.setCenter(getCenterPane());
		pane.setRight(getRightPane());
		pane.setBottom(result);
		Scene scene = new Scene(pane, 400,250);
		stage.setResizable(false);
		stage.setMaxWidth(600);
		stage.setScene(scene);
		stage.setTitle("Temperature Value Converter");
		stage.show();
		
		cal.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if(fahrenheit.isSelected()) {
					calcFahrenheit();
				}
				if(celsius.isSelected()) {
					calcCelsius();
				}
			}
			
		});
	}
	public GridPane getCenterPane() {
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(5,5,5,5));
		pane.setVgap(5.5);
		pane.setHgap(5.5);
		pane.add(celsius, 1, 1);
		pane.add(fahrenheit, 1, 2);
		return pane;
	}
	public GridPane getRightPane() {
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(5,5,5,5));
		pane.setVgap(10);
		pane.setHgap(10);
		textField.setPrefColumnCount(20);
		fahrenheit.setOnAction(e -> {
			if(fahrenheit.isSelected())
			input.setText("Input fahrenheit degree : ");
			
		});
		celsius.setOnAction(e -> {
			if(celsius.isSelected())
			input.setText("Input celsius degree : ");
		});
		pane.add(input, 1, 1);
		pane.add(textField, 1, 2);
		pane.add(cal, 1, 3);
		return pane;
	}
	public void calcFahrenheit() { //calculateCelsius
		try {
			double fahdegree = Double.parseDouble(textField.getText());
			double celdegree = (5.0 / 9) * (fahdegree - 32);
			result.setStyle("-fx-text-fill:blue");
			result.setText("I got Celsius degree " + celdegree + " \nwhich is equal to n" + fahdegree + " fahrenheit degree.");
			
		} catch(Exception ex) {
			result.setStyle("-fx-text-fill:red");
			result.setText("Illegal input value received.");
		}
	}
	public void calcCelsius() { // calculate fahrenheit
		try {
			double celdegree = Double.parseDouble(textField.getText());
			double fahdegree = (9.0 / 5) * celdegree + 32;
			result.setStyle("-fx-text-fill:blue");
			result.setText("I got fahrenheit degree " + fahdegree + " \nwhich is equal to \n" + celdegree + " celsius degree.");
			
		} catch(Exception ex) {
			result.setStyle("-fx-text-fill:red");
			result.setText("Illegal input value received.");
		}
	}
}
