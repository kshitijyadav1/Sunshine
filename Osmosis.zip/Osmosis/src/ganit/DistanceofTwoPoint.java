package ganit;
import java.awt.Toolkit;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.event.*;
import javafx.geometry.*;
public class DistanceofTwoPoint extends Application {
	private TextField xone = new TextField();
	private TextField xtwo = new TextField();
	private TextField yone = new TextField();
	private TextField ytwo = new TextField();
	private Button calc = new Button("Calculate");
	private Label answer = new Label();
	public static void main(String[] args) {
		launch(args);
		
	}

	@Override
	public void start(Stage stage) throws Exception {
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(5,5,5,5));
		String text = "Here you can calculate the distance between two point by inputting x and y value respectively.\n Applied Formula : sqrt(x2 - x1)^2 + (y2 - y1)^2";
		Label toplabel = new Label(text);
		toplabel.setWrapText(true);
		pane.setTop(toplabel);
		pane.setLeft(leftNode());
		pane.setCenter(centerNode());
		answer.setWrapText(true);
		answer.setMinHeight(50);
		pane.setBottom(answer);
		Scene scene = new Scene(pane, 400, 250);
		stage.setScene(scene);
		stage.setTitle("Distance between two points");
		stage.show();
		 calc.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				valueChecker();
			}
		});
		stage.setResizable(false);
	}
	public GridPane centerNode() {
		GridPane p = new GridPane();
		p.setAlignment(Pos.CENTER);
		p.setHgap(5);
		p.setVgap(5);
		p.setPadding(new Insets(5,5,5,5));
		p.add(new Label("X1\t\t"), 1, 1);
		p.add(new Label("Y1\t\t"), 1, 2);
		p.add(new Label("X2\t\t"), 1, 3);
		p.add(new Label("Y2\t\t"), 1, 4);
		p.add(xone, 2, 1);
		p.add(yone, 2, 2);
		p.add(xtwo, 2, 3);
		p.add(ytwo, 2, 4);
		p.add(calc, 2, 5);
		return p;
	}
	public void valueChecker() {
		try {
			double xOne = Double.parseDouble(xone.getText()); //x1
			double yOne = Double.parseDouble(yone.getText()); //Y1
			double xTwo = Double.parseDouble(xtwo.getText()); //x2
			double yTwo = Double.parseDouble(ytwo.getText()); //Y2
			double area = Math.sqrt(Math.pow((xTwo - xOne), 2) + Math.pow((yTwo - yOne), 2));
			answer.setStyle("-fx-fill-text:blue;");
			answer.setText("Distance between two point (x1, y1) and (x2, y2) is " + area);
		} catch(Exception ex) {
			Toolkit.getDefaultToolkit().beep();
			answer.setStyle("-fx-fill-text:red;");
			answer.setText("Illegal input received.");
			System.out.print(ex);
		}
	}
	public GridPane leftNode() {

		GridPane p = new GridPane();
		p.setAlignment(Pos.BASELINE_LEFT);
		p.setPadding(new Insets(5,5,5,5));
		p.add(new Label("\nPoint 1 : "), 1, 1);
		p.add(new Label("\n\n"), 1, 2);
		p.add(new Label("Point 2 : "), 1, 3);
		return p;
	}
}
