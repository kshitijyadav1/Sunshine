package ganit;
import javafx.stage.*;

import java.awt.Toolkit;

import javafx.application.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.*;
public class AreaOfCircle extends Application {
	private float area;
	private float perimeter;
	private TextField textField = new TextField();
	private Button calc = new Button("Calculate");
	private Label result = new Label("");
	private Label presult = new Label(""); //perimeter result holder
	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		BorderPane gp = new BorderPane();
		String text = "Here you can calculate the area of circle and perimeter of circle with using the following formula syntax which is : \nArea of Circle : PI *" + 
				" radius * radius." + "\nPerimeter of Circle  : 2 * PI * radius respectively.\nThe value of PI : " + Math.PI;
		gp.setPadding(new Insets(5,5,5,5));
		Label label = new Label(text);
		label.setWrapText(true);
		gp.setTop(label);
		gp.setCenter(setGPane());
		gp.setBottom(setGBot());
		result.setRotate(0.000000001F);
		textField.setRotate(0.000000001F);
		Scene scene = new Scene(gp, 400, 200);
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Calculate Area Of Circle");
		stage.show();
		calc.setOnAction(new EventHandler<ActionEvent>() { 
			@Override 
			public void handle(ActionEvent e) {
				valueChecker();
			}
		});
	}
	
	
	public void valueChecker() {
		try {
		String tfield = textField.getText();
		float radius = Float.parseFloat(tfield);
		area = (float) (Math.PI * radius * radius);
		perimeter = (float) (2.0 * Math.PI * radius);
		result.setStyle("-fx-text-fill:blue");
		presult.setStyle("-fx-text-fill:blue");
		result.setText("Area of circle : " + Float.toString(area));
		presult.setText("Perimeter of circle : " + Float.toString(perimeter));
		} catch(NumberFormatException ex) {
			Toolkit.getDefaultToolkit().beep();
			result.setStyle("-fx-text-fill:red;");
			result.setText("Illegal input received");
		}
	}
	
	
	public GridPane setGBot() {
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(4,4,4,4));
		pane.setVgap(5.5);
		pane.setHgap(5.5);
		pane.add(result, 2, 1);
		pane.add(presult, 2, 2);
		return pane;
	}
	
	
	public GridPane setGPane() {
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(4,4,4,4));
		pane.setVgap(5.5);
		pane.setHgap(5.5);
		pane.add(new Label("Enter the radius of circle : "), 1, 1);
		pane.add(textField, 2, 1);
		pane.add(calc, 2, 2);
		return pane;
	}

}
