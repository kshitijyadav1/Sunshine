package utility;
import java.awt.Toolkit;

import com.sun.prism.paint.Color;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.event.*;
import javafx.geometry.*;
public class BMIoperation extends Application {
	protected final double POUND_PER_KILOGRAM = 0.45359237; //0.45359237 KILOGRAM = 1 POUND
	protected final double INCH_PER_METER = 0.0254; // 0.0254INCH = 1 METER
	protected final double FOOT_PER_INCH = 12.0000F;//12 INCH = 1 FOOT
	protected final double bmiFormula = 0; // weight / height * height
	protected ToggleGroup height = new ToggleGroup();
	protected ToggleGroup weight = new ToggleGroup();
	protected TextField ench = new TextField();
	protected Label hgt = new Label("Meter");
	protected Label wgt = new Label("Pound");
	protected Label nch = new Label("Inch");
	protected TextField txthgt = new TextField();
	protected TextField txtwgt = new TextField();
	protected Button calc = new Button("Submit");
	protected double answer = 0.0F;
	protected Label result = new Label();
	protected FlowPane paned = new FlowPane();
	RadioButton pound = new RadioButton("Pound");
	RadioButton kilogram = new RadioButton("Kilogram");
	RadioButton meter = new RadioButton("Meter");
	RadioButton foot = new RadioButton("Foot");
	RadioButton inch = new RadioButton("Inch");
	double getWeight = 0.0;
	double getHeight = 0.0;
	BMIoperation() {
		
	}
	@Override
	public void start(Stage stage) throws Exception {
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(5,5,5,5));
		
		pane.setTop(topPortion());
		pane.setLeft(leftPortion());
		pane.setRight(rightPortion());
		pane.setCenter(centerPortion());
		pane.setBottom(paned);
		foot.setOnAction(e -> {
			if(foot.isSelected()) {
				hgt.setText("Foot");
				txthgt.setText("");
				ench.setVisible(true);
				nch.setVisible(true);
			}
		});
		meter.setOnAction(e -> {
			if(meter.isSelected()) {
				hgt.setText("Meter");
				txthgt.setText("");
				ench.setVisible(false);
				nch.setVisible(false);
			}
		});
		inch.setOnAction(e -> {
			if(inch.isSelected()) {
				hgt.setText("Inch");
				txthgt.setText("");
				ench.setVisible(false);
				nch.setVisible(false);
			}
		});
		pound.setOnAction(e -> {
			if(pound.isSelected()) {
				txtwgt.setText("");
				wgt.setText("Pound");
			}
		});
		kilogram.setOnAction(e -> {
			if(kilogram.isSelected()) {
				txtwgt.setText("");
				wgt.setText("Kilogram");
			}
		});
		calc.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				valueChecker();
			}
		});
		
		Scene scene = new Scene(pane, 500,400);
		stage.setScene(scene);
		stage.setTitle("BMI");
		stage.setResizable(false);
		stage.show();
	}
	
	
	public VBox topPortion() {
		String text = "Here you can calculate your body mass index by just inserting your body weight and height by picking up on right and left column, So why're you waiting for? Let's enjoy the application.\n"
				+ "Applied Formula = Weight / (height * height)";
		VBox vbox = new VBox();
		vbox.setPadding(new Insets(10,10,10,10));
		Label head = new Label("BMI (Body Mass Index)");
		head.setFont(Font.font("Arial", FontWeight.LIGHT, FontPosture.REGULAR, 25));
		head.setStyle("-fx-text-fill:#004565;");
		head.setUnderline(true);
		HBox hbox = new HBox();
		hbox.getChildren().add(head);
		hbox.setAlignment(Pos.CENTER);
		HBox hbox1 = new HBox();
		Label secondHead = new Label(text);
		secondHead.setWrapText(true);
		hbox1.getChildren().add(secondHead);
		hbox1.setAlignment(Pos.CENTER);
		vbox.getChildren().addAll(hbox,hbox1);
		
		return vbox;
	}
	
	public VBox leftPortion() {
		VBox vbox = new VBox();
		
		pound.setToggleGroup(weight);
		kilogram.setToggleGroup(weight);
		vbox.getChildren().add(pound);
		vbox.getChildren().add(kilogram);
		weight.selectToggle(pound);
		
		return vbox;
	}
	
	public VBox rightPortion() {
		VBox vbox = new VBox();
		
		
		meter.setToggleGroup(height);
		foot.setToggleGroup(height);
		inch.setToggleGroup(height);
		height.selectToggle(meter);
		vbox.getChildren().add(meter);
		vbox.getChildren().add(foot);
		vbox.getChildren().add(inch);
		
		return vbox;
	}
	
	public GridPane centerPortion() {
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setVgap(4);
		pane.setHgap(4);
		pane.setPadding(new Insets(5,5,5,5));
		txthgt.setMaxWidth(70);
		txtwgt.setMaxWidth(70);
		ench.setMaxWidth(70);
		pane.add(hgt, 1, 1);
		pane.add(txthgt, 2, 1);
		nch.setVisible(false);
		pane.add(nch, 3, 1);
		ench.setVisible(false);
		pane.add(ench, 4, 1);
		pane.add(wgt, 1, 2);
		pane.add(txtwgt, 2, 2);
		pane.add(calc, 2, 3);
		
		return pane;
	}
	public void valueChecker() {
		int msg = 0;
		try {
			if(pound.isSelected()) {
			getWeight = Double.parseDouble(txtwgt.getText()) * POUND_PER_KILOGRAM; 
			}
			if(meter.isSelected()) {
			getHeight = Double.parseDouble(txthgt.getText());
			}
			if(kilogram.isSelected()) {
				getWeight = Double.parseDouble(txtwgt.getText());
			}
			if(foot.isSelected()) {
				getHeight = 0.0;
				double fght = Double.parseDouble(txthgt.getText()) * FOOT_PER_INCH;
				double getInchHeight = Double.parseDouble(ench.getText());
				getHeight = fght + getInchHeight;
				getHeight *= INCH_PER_METER;
			}
			if(inch.isSelected()) {
				getHeight = Double.parseDouble(txthgt.getText()) * INCH_PER_METER;
			}
			answer = getWeight / Math.pow(getHeight, 2);
			msg = 200;
			designDialog(msg, answer);
		} catch(Exception ex) {
			msg = 404;
			Toolkit.getDefaultToolkit().beep();
			designDialog(msg, answer);
		}
	}

	public void designDialog(int msg, double answer) {
		paned.setMinHeight(100);
		paned.setAlignment(Pos.CENTER);
		paned.setPadding(new Insets(5,5,5,5));
		
		if(msg == 200) {
		String txt = "I've got your BMI which is " + answer + ".\nIt's interpreting that you are " +BMIChecker()+"";
		result.setText(txt);
		result.setWrapText(true);
		paned.getChildren().clear();
		paned.getChildren().add(result);
		}
		if(msg == 404) {
			result.setStyle("-fx-text-fill:#ff0000; -fx-background-color:white;");
			String txt1 = "Illegal input received.";
		result.setText(txt1);
		result.setWrapText(true);
		paned.getChildren().clear();
		paned.getChildren().add(result);
		}
	}
	
	public String BMIChecker() {
		String msg="you're ";
		if(answer < 18.5) {
			result.setStyle("-fx-text-fill:orange; -fx-background-color:black;");
			msg += "\"Underweight\", \nNotice : I think you have to increase your diet plan.";
		}
		else if(answer < 25) {
			result.setStyle("-fx-text-fill:green; -fx-background-color:white;");
			msg += "\"Normal\".";
		}
		else if(answer < 30) {
			result.setStyle("-fx-text-fill:#990000; -fx-background-color:white;");
			msg += "\"Overweight\", \nNotice : I think you should have to decrease your diet plan.";
		}
		else {
			result.setStyle("-fx-text-fill:#ff0000;");
			msg += "\"Obese\",\n\nI think you should have to follow some restrictive rule on dieting.";
		}
		return msg;
	}
	
}