package utility;
public class BMI extends BMIoperation {
	public static void main(String[] args) {
		BMIoperation o = new BMIoperation();
		o.launch(args);
	}
}
